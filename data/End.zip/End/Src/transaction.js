
class Transaction {

  constructor(stockName, previousDay, nextDay,news,stockPrediction) {
    this.stockName = stockName
    this.previousDay = previousDay
    this.nextDay = nextDay
    this.news = news
    this.stockPrediction = stockPrediction
  }

}

module.exports = Transaction
