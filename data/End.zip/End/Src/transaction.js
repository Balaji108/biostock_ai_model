
class Transaction {

  constructor(stockName, stockPrice) {
    this.stockName = stockName
    this.stockPrice = stockPrice
  }

}

module.exports = Transaction
