

class BlockchainNode {

  constructor(url) {
    this.url = url
  }

}

module.exports = BlockchainNode
